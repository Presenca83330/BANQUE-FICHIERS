import React, { useState } from 'react';
import GraphFormAccueil from '../../5-Graphisme/1.GraphFormulaires/4.GraphFormAccueil.jsx';
import FormReseauCreation from './2.FormReseauCreation';
import FormReseauGestion from './3.FormReseauGestion';

interface FormReseauAccueilProps {
  onBack?: () => void;
}

const FormReseauAccueil: React.FC<FormReseauAccueilProps> = ({ onBack }) => {
  const [currentView, setCurrentView] = useState('accueil');
  const handleCreationClick = () => {
    setCurrentView('creation');
  };
  const handleMiseAJourClick = () => {
    setCurrentView('gestion');
  };
  const handleBackToAccueil = () => {
    setCurrentView('accueil');
  };
  if (currentView === 'creation') {
    return <FormReseauCreation onBack={handleBackToAccueil} />;
  }
  if (currentView === 'gestion') {
    return <FormReseauGestion onBack={handleBackToAccueil} />;
  }
  return <GraphFormAccueil onCreationClick={handleCreationClick} onMiseAJourClick={handleMiseAJourClick} />;
};
export default FormReseauAccueil;
