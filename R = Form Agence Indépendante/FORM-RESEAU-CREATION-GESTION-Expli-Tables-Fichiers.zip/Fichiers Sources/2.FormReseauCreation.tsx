import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Building2 } from "lucide-react";
import { useReseauCreation } from "@/components/HOOKS-STRATEGIQUE/5.HOOKS-CreationCompteAdminPresenca/1.Reseau/useReseauCreation";
import SuccessAccountInfo from "./SuccessAccountInfo";
import type {
  ReseauCreationData,
  ReseauValidationErrors,
  ReseauCreationResult,
} from "@/components/HOOKS-STRATEGIQUE/5.HOOKS-CreationCompteAdminPresenca/1.Reseau/types";

interface FormReseauCreationProps {
  onBack: () => void;
}

export default function FormReseauCreation({ onBack }: FormReseauCreationProps) {
  const { createReseau, isLoading, error } = useReseauCreation();

  const [formData, setFormData] = useState<ReseauCreationData>({
    nomReseau: "",
    adresse: "",
    codePostal: "",
    ville: "",
    siret: "",
    nomResponsable: "",
    prenomResponsable: "",
    emailResponsable: "",
    telephoneResponsable: "",
  });

  const [errors, setErrors] = useState<ReseauValidationErrors>({});
  const [creationResult, setCreationResult] = useState<ReseauCreationResult | null>(null);

  const updateFormData = (field: keyof ReseauCreationData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validateForm = (): boolean => {
    const newErrors: ReseauValidationErrors = {};

    if (!formData.nomReseau) newErrors.nomReseau = "Nom du réseau requis";
    if (!formData.adresse) newErrors.adresse = "Adresse requise";
    if (!formData.codePostal) newErrors.codePostal = "Code postal requis";
    if (!formData.ville) newErrors.ville = "Ville requise";
    if (!formData.siret) newErrors.siret = "SIRET requis";
    if (!formData.nomResponsable) newErrors.nomResponsable = "Nom requis";
    if (!formData.prenomResponsable) newErrors.prenomResponsable = "Prénom requis";
    if (!formData.emailResponsable) newErrors.emailResponsable = "Email requis";
    if (!formData.telephoneResponsable)
      newErrors.telephoneResponsable = "Téléphone requis";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Soumission formulaire", formData);

    const isValid = validateForm();
    console.log("Résultat validation:", isValid);
    if (!isValid) return;

    const result = await createReseau(formData);
    console.log("Résultat createReseau:", result);
    if (result) {
      setCreationResult(result);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Building2 className="h-6 w-6 text-primary" />
            <CardTitle>Création d’un nouveau réseau</CardTitle>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Informations Réseau */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="nomReseau">Nom du réseau *</Label>
                <Input
                  id="nomReseau"
                  value={formData.nomReseau}
                  onChange={(e) => updateFormData("nomReseau", e.target.value)}
                  placeholder="Nom du Réseau"
                />
                {errors.nomReseau && (
                  <p className="text-sm text-red-500">{errors.nomReseau}</p>
                )}
              </div>

              <div>
                <Label htmlFor="siret">Siret *</Label>
                <Input
                  id="siret"
                  value={formData.siret}
                  onChange={(e) => updateFormData("siret", e.target.value)}
                  placeholder="N° Siret du Réseau"
                />
                {errors.siret && (
                  <p className="text-sm text-red-500">{errors.siret}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="adresse">Adresse *</Label>
              <Input
                id="adresse"
                value={formData.adresse}
                onChange={(e) => updateFormData("adresse", e.target.value)}
                placeholder="Adresse. Siège Réseau"
              />
              {errors.adresse && (
                <p className="text-sm text-red-500">{errors.adresse}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="codePostal">Code postal *</Label>
                <Input
                  id="codePostal"
                  value={formData.codePostal}
                  onChange={(e) => updateFormData("codePostal", e.target.value)}
                  placeholder="Code Postal. Siège Réseau"
                />
                {errors.codePostal && (
                  <p className="text-sm text-red-500">{errors.codePostal}</p>
                )}
              </div>
              <div>
                <Label htmlFor="ville">Ville *</Label>
                <Input
                  id="ville"
                  value={formData.ville}
                  onChange={(e) => updateFormData("ville", e.target.value)}
                  placeholder="Ville. Siège Réseau"
                />
                {errors.ville && (
                  <p className="text-sm text-red-500">{errors.ville}</p>
                )}
              </div>
            </div>

            {/* Responsable */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="prenomResponsable">Prénom Direction *</Label>
                <Input
                  id="prenomResponsable"
                  value={formData.prenomResponsable}
                  onChange={(e) =>
                    updateFormData("prenomResponsable", e.target.value)
                  }
                  placeholder="Prénom. Reseau Direction"
                />
                {errors.prenomResponsable && (
                  <p className="text-sm text-red-500">
                    {errors.prenomResponsable}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="nomResponsable">Nom Direction *</Label>
                <Input
                  id="nomResponsable"
                  value={formData.nomResponsable}
                  onChange={(e) =>
                    updateFormData("nomResponsable", e.target.value)
                  }
                  placeholder="Nom. Reseau Direction"
                />
                {errors.nomResponsable && (
                  <p className="text-sm text-red-500">
                    {errors.nomResponsable}
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="emailResponsable">Email Direction *</Label>
                <Input
                  id="emailResponsable"
                  value={formData.emailResponsable}
                  onChange={(e) =>
                    updateFormData("emailResponsable", e.target.value)
                  }
                  placeholder="Email. Reseau Direction"
                />
                {errors.emailResponsable && (
                  <p className="text-sm text-red-500">
                    {errors.emailResponsable}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="telephoneResponsable">
                  Téléphone Direction *
                </Label>
                <Input
                  id="telephoneResponsable"
                  value={formData.telephoneResponsable}
                  onChange={(e) =>
                    updateFormData("telephoneResponsable", e.target.value)
                  }
                  placeholder="Tél. Reseau Direction"
                />
                {errors.telephoneResponsable && (
                  <p className="text-sm text-red-500">
                    {errors.telephoneResponsable}
                  </p>
                )}
              </div>
            </div>

            {/* Boutons */}
            <div className="flex justify-between pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={onBack}
                disabled={isLoading}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Retour
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Création en cours..." : "Créer le réseau"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Affichage des informations de connexion après succès */}
      {creationResult && (
        <SuccessAccountInfo
          email={creationResult.email}
          tempPassword={creationResult.tempPassword}
        />
      )}
    </div>
  );
}
